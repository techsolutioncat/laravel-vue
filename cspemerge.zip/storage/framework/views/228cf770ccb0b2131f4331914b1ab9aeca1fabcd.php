<?php echo $__env->make('auth.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title'); ?>
    ログイン
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="text_c top_50">

    <div class="w_230 auto p2020 border_ccc">
        <form method="POST" action="/login">
            <?php echo csrf_field(); ?>
            <div class="bottom_10">
                <span class="right_5"><?php echo e(__('ログインID')); ?></span>
                <input id="login_id" type="text" name="login_id" class="w_110 form-control <?php $__errorArgs = ['login_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

            </div>
            <div>
                <span class="right_5"><?php echo e(__('パスワード')); ?></span>
                <input id="password" type="password" name="password" class="w_110 form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
            <div class="top_20">
                <button type="submit" class="l_btn create_btn">
                    <?php echo e(__('ログイン')); ?>

                </button>
            </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/auth/login.blade.php ENDPATH**/ ?>