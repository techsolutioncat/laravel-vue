<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title'); ?>
    会社管理
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="inner"><company-header company_name="<?php echo e($company_name); ?>" company_id="<?php echo e($company_id); ?>" path="1"></company-header></div>
    <device-component company_id="<?php echo e($company_id); ?>"></device-component>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/company/device.blade.php ENDPATH**/ ?>