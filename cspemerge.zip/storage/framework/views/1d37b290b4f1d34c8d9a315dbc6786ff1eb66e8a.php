<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> |<?php echo e(config('app.name', 'Laravel')); ?></title>

    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.11"></script>

    <!-- Fonts -->

    <link rel="shortcut icon" href="/img/favicon.png" type="image/vnd.microsoft.icon">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('css/loader.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>
<div id="app">
    <?php echo $__env->yieldContent('head'); ?>
    <main class="py-4">
        <?php if(session('error')): ?>
        <div class="w_100p p1020">
            <div class="inner p1020">
                    <span class="font_alert font_16">
                        <?php echo e(session('error') ?? ''); ?>

                    </span>
                <?php if(session('error_list')): ?>
                <?php $__currentLoopData = session('error_list'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="font_alert font_14"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        
        
            
                
                    
                    
                
            
        

        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <modal-component message="<?php echo e($errors->first('message')); ?>"></modal-component>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <div class="pop modal-content pop-box" id="logout-modal" style="width:400px!important;">

        <p class="top_10 bottom_20 text_c">ログアウトしますか？</p>

        <div class="top_20">
            <div class="text_c space">
                <a class="return_btn l_btn space_normal right_5 modal-close">キャンセル</a>
                <a class="details_btn l_btn space_normal left_5"
                   onclick="document.getElementById('logout-form').submit();">OK</a>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<?php $__env->startSection('scripts'); ?>
 <!-- Here you call the select2 js plugin -->
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vue.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vue-simple-search-dropdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/layouts/app.blade.php ENDPATH**/ ?>