<?php $__env->startSection('head'); ?>
    <?php
        $path = parse_url(url()->current());
        $paths = explode("/", $path['path']);
        $category = $paths[1] ?? '';
    ?>
<header>
    <!-- ローディング画面 -->
    <div id="loading">
        <div class="half-circle-spinner">
            <div class="circle circle-1"></div>
            <div class="circle circle-2"></div>
            </div>
    </div>
    <div class="w_100p h_70 p_fixed main_color z_99">
        <div class="inner clearfix h_70">
            <div class="float_l left_10">
                <a href="<?php echo e(url('/')); ?>">
                    <h1 class="font_white font_25 h_70 l_height70 font_normal">エマージェ端末管理</h1>
                </a>
            </div>
            <div class="float_r">
                <ul class="text_c d_flex">
                    <!-- <?php if(Auth::user()->userRole->auth >= 3): ?>
                        <?php if(strpos($category,'notice') !== false): ?>
                                <li class="w_120 block border_l active">
                        <?php else: ?>
                            <li class="w_120 block border_l">
                        <?php endif; ?>
                            <a class="font_white font_14 block l_height70 textnone" href="<?php echo e(route('notice')); ?>">

                                <span class="inblock w_14">
                                    <img class="w_100p" src="/img/news.png" >
                                </span>
                                <span class="font_white">
                                受信一覧
                                </span>
                            </a>
                        </li>
                    <?php endif; ?> -->

                    <?php if(Auth::user()->userRole->auth > 0): ?>
                        <?php if(strpos($category,'history')  !== false): ?>
                            <li class="w_120 block border_l active">
                        <?php else: ?>
                            <li class="w_120 block border_l">
                        <?php endif; ?>
                            <a class="font_white font_14 block l_height70 textnone" href="<?php echo e(route('history')); ?>">
                                <span class="inblock w_14">
                                    <img class="w_100p" src="/img/history.png" >
                                </span>
                                <span class="font_white">
                                    履歴管理
                                </span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->userRole->auth >= 2): ?>
                        <?php if(strpos($category,'device')  !== false): ?>
                            <li class="w_120 block border_l active">
                        <?php else: ?>
                            <li class="w_120 block border_l">
                        <?php endif; ?>
                            <a class="font_14 block l_height70 textnone" href="<?php echo e(route('device')); ?>">
                                <span class="inblock w_14">
                                    <img class="w_100p" src="/img/terminal.png" >
                                </span>
                                <span class="font_white">
                                    端末管理
                                </span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->userRole->auth >= 3): ?>
                        <?php if(strpos($category,'admin')  !== false): ?>
                            <li class="w_120 block border_l active">
                        <?php else: ?>
                            <li class="w_120 block border_l">
                        <?php endif; ?>
                                <a class="font_14 block l_height70 textnone" href="<?php echo e(route('admin')); ?>">
                                    <span class="inblock w_14">
                                        <img class="w_100p" src="/img/admin.png" >
                                    </span>
                                    <span class="font_white">
                                    <?php if(Auth::user()->userRole->auth > 3): ?>
                                        管理者管理
                                    <?php endif; ?>
                                    <?php if(Auth::user()->userRole->auth == 3): ?>
                                        ユーザー管理
                                    <?php endif; ?>
                                    </span>
                                </a>
                            </li>
                    <?php endif; ?>

                    <?php if(Auth::user()->userRole->auth >= 2 || Auth::user()->userRole->auth == 0): ?>
                        <?php if(strpos($category,'company') !== false): ?>
                            <li class="w_120 block border_l active">
                        <?php else: ?>
                            <li class="w_120 block border_l">
                        <?php endif; ?>
                                <a class="font_14 block l_height70 textnone" href="<?php echo e(route('company')); ?>">
                                    <span class="inblock w_14">
                                        <img class="w_100p" src="/img/company_info.png" >
                                    </span>
                                    <span class="font_white">
                                    契約先情報
                                    </span>
                                </a>
                            </li>
                    <?php endif; ?>

                    <li class="w_120 block border_l base_color">
                        <a class="font_main font_14 l_height70 textnone" id="logout_btn" href=""
                            onclick="event.preventDefault();
                            //document.getElementById('logout-form').submit();
                            ">
                                <?php echo e(__('ログアウト')); ?>

                        </a>
                        
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="h_70"></div>
</header>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/layouts/head.blade.php ENDPATH**/ ?>