<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title'); ?>
    履歴管理
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($isAdmin): ?>
    <history-header history_type="device"></history-header>
    <?php endif; ?>
    <history-component></history-component>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script !src="">
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/history/index.blade.php ENDPATH**/ ?>