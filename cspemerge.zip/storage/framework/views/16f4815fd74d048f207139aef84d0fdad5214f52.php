<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title'); ?>
    受信一覧詳細
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="inner">
        <section class="top_20 bottom_20">
            <h2 class="font_20 border_title p_left10 l_height20">受信一覧詳細</h2>
        </section>
    </div>
    <history-detail-component :parent="'notice'">
    </history-detail-component>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script !src="">
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/notice/detail.blade.php ENDPATH**/ ?>