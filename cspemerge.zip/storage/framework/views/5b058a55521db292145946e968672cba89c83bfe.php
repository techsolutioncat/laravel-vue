<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title'); ?>
    端末詳細
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($company)): ?>
    <div class="inner">
        <company-header company_name="<?php echo e($company->name); ?>"
                        company_id="<?php echo e($company->id); ?>"
                        path="1">
        </company-header>
    </div>
    <?php endif; ?>
    <device-detail-component>
    </device-detail-component>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script !src="">
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/device/detail.blade.php ENDPATH**/ ?>