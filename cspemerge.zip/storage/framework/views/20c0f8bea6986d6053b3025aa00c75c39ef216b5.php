<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title'); ?>
    契約先情報
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <company-detail-component></company-detail-component>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script !src="">
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cspemerge\resources\views/company/detail.blade.php ENDPATH**/ ?>