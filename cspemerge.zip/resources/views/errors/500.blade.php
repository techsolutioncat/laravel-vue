@extends('layouts.app')

@include('layouts.head')

@section('title')
    エラー
@endsection

@section('content')
{{--エラー:{{message}}--}}
@endsection


@section('script')
    <script !src="">
    </script>
@endsection


