@extends('layouts.app')

@include('layouts.head')

@section('title')
管理者管理
@endsection

@section('content')
<admin-component></admin-component>


@endsection


@section('script')
<script !src="">
</script>
@endsection


