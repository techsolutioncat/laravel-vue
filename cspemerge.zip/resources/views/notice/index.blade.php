@extends('layouts.app')

@include('layouts.head')

@section('title')
    受信一覧
@endsection

@section('content')
    <notice-component></notice-component>
@endsection

@section('script')
    <script !src="">
    </script>
@endsection


