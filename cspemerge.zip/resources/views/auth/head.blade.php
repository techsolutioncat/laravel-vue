@section('head')
    <header class="main_color text_c">
        <h1 class="font_white font_25 h_70 l_height70 font_normal">エマージェPlusコンシェル</h1>
    </header>
@endsection
