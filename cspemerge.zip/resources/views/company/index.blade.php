@extends('layouts.app')

@include('layouts.head')

@section('title')
    会社情報
@endsection

@section('content')
    <company-component></company-component>
@endsection


@section('script')
    <script !src="">
    </script>
@endsection


