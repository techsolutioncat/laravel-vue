@extends('layouts.app')

@include('layouts.head')


@section('title')
    契約先情報
@endsection

@section('content')
    <company-detail-component></company-detail-component>
@endsection

@section('script')
    <script !src="">
    </script>
@endsection
