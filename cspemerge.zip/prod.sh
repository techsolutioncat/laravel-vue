composer dump-autoload
php artisan clear-compiled
php artisan optimize
php artisan config:cache
php artisan route:cache
npm run prod
php artisan view:cache
