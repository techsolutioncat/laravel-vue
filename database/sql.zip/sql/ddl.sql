create table companies
(
    id              bigint unsigned auto_increment
        primary key,
    name            varchar(255)                        not null comment '会社 名前',
    phone           varchar(255)                        not null comment '会社 電話番号',
    postcode        varchar(255)                        not null comment '会社 郵便番号',
    address         varchar(255)                        not null comment '会社 住所',
    owner_name      varchar(255)                        not null comment '責任者 氏名',
    owner_mail      varchar(255)                        not null comment '責任者 メールアドレス',
    sb_payment_no   varchar(10)                         not null comment '架No（管理番号）',
    message_enabled tinyint(1)                          not null comment 'メッセージ機能の利用可否',
    created_at      timestamp default CURRENT_TIMESTAMP null,
    updated_at      timestamp default CURRENT_TIMESTAMP null
)
    comment '会社情報' collate = utf8mb4_unicode_ci;

create table device_groups
(
    id         bigint unsigned auto_increment
        primary key,
    name       varchar(255) not null comment 'グループの名称',
    created_at timestamp    null,
    updated_at timestamp    null
)
    comment '端末グループ' collate = utf8mb4_unicode_ci;

create table device_reports
(
    id                   bigint unsigned auto_increment
        primary key,
    device_assignment_id bigint unsigned not null comment '端末設定への外部キー',
    device_signal_id     int unsigned    not null comment '端末信号への外部キー',
    lat                  double          null comment '緯度',
    lng                  double          null comment '経度',
    battery              int unsigned    null comment 'バッテリー残量',
    dealt_with_at        timestamp       null comment '対応日（管理画面で設定）',
    created_at           timestamp       null,
    updated_at           timestamp       null,
    supplement           varchar(255)    null comment '補足'
)
    comment '端末レポート（端末からアップロードされたデータ）' collate = utf8mb4_unicode_ci;

create table device_report_messages
(
    id                   bigint unsigned auto_increment
        primary key,
    device_report_id     bigint unsigned      not null comment '端末レポートへの外部キー',
    device_assignment_id bigint unsigned      not null comment '端末設定（メッセージの送信先）',
    received             tinyint(1) default 0 not null,
    created_at           timestamp            null,
    updated_at           timestamp            null,
    constraint device_report_messages_device_report_id_foreign
        foreign key (device_report_id) references device_reports (id)
)
    comment '端末レポートに対応するメッセージ履歴' collate = utf8mb4_unicode_ci;

create table device_signals
(
    id          int unsigned auto_increment
        primary key,
    response    varchar(255) not null comment '端末レポートの対応文字列',
    signal_int  int unsigned not null comment '信号',
    description varchar(255) not null comment '信号の補足説明',
    created_at  timestamp    null,
    updated_at  timestamp    null
)
    comment '端末の信号' collate = utf8mb4_unicode_ci;

create table device_types
(
    id         int unsigned auto_increment
        primary key,
    type       varchar(255) not null comment '型番',
    created_at timestamp    null,
    updated_at timestamp    null
)
    comment '端末の型番' collate = utf8mb4_unicode_ci;

create table devices
(
    id             bigint unsigned auto_increment
        primary key,
    imei           varchar(15)  null comment 'ハードウェア端末のIMEI',
    device_type_id int unsigned not null comment 'ハードウェア端末の型番',
    created_at     timestamp    null,
    updated_at     timestamp    null,
    constraint devices_imei_unique
        unique (imei),
    constraint devices_device_type_id_foreign
        foreign key (device_type_id) references device_types (id)
)
    comment 'ハードウェア端末の情報' collate = utf8mb4_unicode_ci;

create table sims
(
    id         bigint unsigned auto_increment
        primary key,
    iccid      varchar(20)  not null comment 'ICCID番号',
    msn        varchar(255) not null comment '電話番号',
    created_at timestamp    null,
    updated_at timestamp    null,
    constraint sims_iccid_unique
        unique (iccid)
)
    comment 'SIM情報' collate = utf8mb4_unicode_ci;

create table device_sims
(
    id          bigint unsigned auto_increment
        primary key,
    device_imei varchar(15)          null comment 'IMEI番号',
    sim_iccid   varchar(20)          null comment 'ICCID番号（SIM固有）',
    active      tinyint(1) default 0 null comment '稼働状況（１電源ON、０電源OFF）',
    battery     int        default 0 null comment 'バッテリー残量',
    deleted_at  timestamp            null comment '削除日時',
    created_at  timestamp            null,
    updated_at  timestamp            null,
    constraint device_sims_devices_imei_fk
        foreign key (device_imei) references devices (imei),
    constraint device_sims_sims_iccid_fk
        foreign key (sim_iccid) references sims (iccid)
)
    comment 'ハードウェア端末とSIMの対応' collate = utf8mb4_unicode_ci;

create table device_assignments
(
    id              bigint unsigned auto_increment
        primary key,
    device_sim_id   bigint unsigned      not null comment '端末SIM',
    device_group_id bigint unsigned      null comment '端末グループ',
    company_id      bigint unsigned      not null comment '会社情報',
    name            varchar(255)         null comment '各端末の名前',
    mount_no        varchar(8)           not null comment '架No（管理番号）',
    rest            tinyint(1) default 0 not null comment '休止状態（1休止、0稼働）',
    applied_at      timestamp            null comment '設定反映日時',
    started_at      timestamp            null comment '利用開始日時',
    ended_at        timestamp            null comment '利用停止日時',
    restored_at     timestamp            null comment '復元日時',
    deleted_at      timestamp            null comment '削除日時',
    created_at      timestamp            null,
    updated_at      timestamp            null,
    constraint device_assignments_company_id_foreign
        foreign key (company_id) references companies (id),
    constraint device_assignments_device_group_id_foreign
        foreign key (device_group_id) references device_groups (id),
    constraint device_assignments_device_sim_id_foreign
        foreign key (device_sim_id) references device_sims (id)
)
    comment '端末設定' collate = utf8mb4_unicode_ci;

create index device_sims_device_imei_foreign
    on device_sims (device_imei);

create index device_sims_sim_iccid_foreign
    on device_sims (sim_iccid);

create table messages
(
    id                   bigint unsigned auto_increment
        primary key,
    device_assignment_id bigint unsigned not null comment '端末設定',
    device_signal_id     int unsigned    not null comment '信号',
    message              char(48)        null comment 'メッセージ',
    created_at           timestamp       null,
    updated_at           timestamp       null,
    constraint messages_device_assignment_id_foreign
        foreign key (device_assignment_id) references device_assignments (id),
    constraint messages_device_signal_id_foreign
        foreign key (device_signal_id) references device_signals (id)
)
    comment '端末設定に対応したメッセージ' collate = utf8mb4_unicode_ci;

create table phones
(
    id                   bigint unsigned auto_increment
        primary key,
    device_assignment_id bigint unsigned not null comment '端末設定',
    auth_no              int unsigned    not null comment '0から10の管理番号',
    name                 varchar(255)    null comment '名称（電話番号のラベル）',
    phone                varchar(255)    null comment '電話番号',
    created_at           timestamp       null,
    updated_at           timestamp       null,
    constraint phones_device_assignment_id_foreign
        foreign key (device_assignment_id) references device_assignments (id)
)
    comment '端末設定に対応する電話番号' collate = utf8mb4_unicode_ci;

create table positions
(
    id               bigint auto_increment comment 'requestNoと併用'
        primary key,
    device_sim_id    bigint unsigned                    not null comment '端末SIM',
    device_report_id bigint unsigned                    null comment '端末レポート',
    requested_at     datetime                           null comment '位置情報のリクエスト日時',
    resulted_at      datetime                           null comment '位置情報のアップロード日時',
    updated_at       datetime default CURRENT_TIMESTAMP null,
    created_at       datetime default CURRENT_TIMESTAMP null,
    constraint positions_device_reports_id_fk
        foreign key (device_report_id) references device_reports (id),
    constraint positions_device_sims_id_fk
        foreign key (device_sim_id) references device_sims (id)
)
    comment '位置情報';

create table user_roles
(
    id         int unsigned auto_increment
        primary key,
    role       varchar(255) not null comment '役割名称',
    auth       int unsigned not null comment '権限レベル',
    created_at timestamp    null,
    updated_at timestamp    null
)
    comment 'ユーザーの役割' collate = utf8mb4_unicode_ci;

create table users
(
    id                bigint unsigned auto_increment
        primary key,
    login_id          varchar(255)    not null comment 'ログインID',
    name              varchar(255)    not null comment 'ユーザー名',
    password          varchar(255)    not null comment 'パスワード',
    company_id        bigint unsigned null comment '会社情報',
    user_role_id      int unsigned    not null comment 'ユーザーロール',
    enabled           tinyint(1)      not null comment '利用可否（１可０不可）',
    deleted_at        timestamp       null comment '削除日時',
    remember_token    varchar(100)    null,
    login_verified_at timestamp       null,
    created_at        timestamp       null,
    updated_at        timestamp       null,
    constraint users_login_id_unique
        unique (login_id),
    constraint users_name_uindex
        unique (name),
    constraint users_company_id_foreign
        foreign key (company_id) references companies (id),
    constraint users_user_role_id_foreign
        foreign key (user_role_id) references user_roles (id)
)
    comment 'ユーザー情報' collate = utf8mb4_unicode_ci;

create table device_settings
(
    id                   bigint unsigned auto_increment
        primary key,
    device_assignment_id bigint unsigned      not null comment '端末設定',
    user_id              bigint unsigned      not null comment 'ユーザー情報',
    device_sim_id        bigint unsigned      not null comment '端末SIM',
    device_group_id      bigint unsigned      null comment '端末グループ',
    company_id           bigint unsigned      not null comment '会社情報',
    mount_no             varchar(8)           not null comment '架No',
    name                 varchar(255)         null comment '端末名称',
    applied_at           timestamp            null comment '設定適用の日時',
    created_at           timestamp            null,
    updated_at           timestamp            null,
    rest                 tinyint(1) default 0 not null comment '休止状態',
    started_at           timestamp            null comment '利用開始日時',
    ended_at             timestamp            null comment '利用停止日時',
    restored_at          timestamp            null comment '復元日時',
    deleted_at           timestamp            null comment '削除日時',
    constraint device_settings_company_id_foreign
        foreign key (company_id) references companies (id),
    constraint device_settings_device_assignment_id_foreign
        foreign key (device_assignment_id) references device_assignments (id),
    constraint device_settings_device_group_id_foreign
        foreign key (device_group_id) references device_groups (id),
    constraint device_settings_device_sim_id_foreign
        foreign key (device_sim_id) references device_sims (id),
    constraint device_settings_user_id_foreign
        foreign key (user_id) references users (id)
)
    comment '端末の設定履歴' collate = utf8mb4_unicode_ci;

create table device_setting_messages
(
    id                bigint unsigned auto_increment
        primary key,
    device_setting_id bigint unsigned not null comment '端末設定履歴',
    device_signal_id  int unsigned    not null comment '信号',
    message           char(48)        null comment 'メッセージ文字列',
    updated_at        timestamp       null,
    created_At        timestamp       null,
    constraint device_setting_messages_device_setting_id_foreign
        foreign key (device_setting_id) references device_settings (id),
    constraint device_setting_messages_device_signal_id_foreign
        foreign key (device_signal_id) references device_signals (id)
)
    comment '端末設定履歴のメッセージ' collate = utf8mb4_unicode_ci;

create table device_setting_phones
(
    id                bigint unsigned auto_increment
        primary key,
    device_setting_id bigint unsigned not null comment '端末設定履歴',
    auth_no           int unsigned    not null comment '0から10の管理番号',
    name              varchar(255)    null comment '名称（電話番号へラベル）',
    phone             varchar(255)    null comment '電話番号',
    created_at        timestamp       null,
    updated_at        timestamp       null,
    constraint device_setting_phones_device_setting_id_foreign
        foreign key (device_setting_id) references device_settings (id)
)
    comment '端末の設定履歴（電話番号）' collate = utf8mb4_unicode_ci;

