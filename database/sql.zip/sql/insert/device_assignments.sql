SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_assignments (id, device_sim_id, device_group_id, company_id, name, mount_no, rest, applied_at, started_at, ended_at, restored_at, deleted_at, created_at, updated_at) VALUES (1, 1, 1, 1, 'A端末', '99999999', 0, null, '2020-06-11 00:29:59', null, null, null, '2020-06-11 00:29:59', '2020-07-09 10:26:42');
INSERT INTO device_assignments (id, device_sim_id, device_group_id, company_id, name, mount_no, rest, applied_at, started_at, ended_at, restored_at, deleted_at, created_at, updated_at) VALUES (2, 2, 1, 1, 'B端末', '99999999', 1, null, '2020-06-08 03:04:15', null, null, '2020-07-09 10:01:25', '2020-06-08 03:04:15', '2020-07-09 10:01:25');
INSERT INTO device_assignments (id, device_sim_id, device_group_id, company_id, name, mount_no, rest, applied_at, started_at, ended_at, restored_at, deleted_at, created_at, updated_at) VALUES (3, 3, 1, 1, 'C端末', '99999999', 1, null, '2020-06-08 03:04:15', null, null, null, '2020-06-08 03:04:18', '2020-07-09 10:06:09');

SET FOREIGN_KEY_CHECKS = 1;