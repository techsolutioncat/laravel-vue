SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO companies (id, name, phone, postcode, address, owner_name, owner_mail, sb_payment_no, message_enabled, created_at, updated_at) VALUES (1, 'ITZテスト株式会社', '00000000', '0000000', 'ITZ県テスト市 1-2-4', 'ITZテスト 代表', 'mail@mailtest.test', '22239493', 1, '2020-05-18 22:17:14', '2020-05-26 10:28:52');
INSERT INTO companies (id, name, phone, postcode, address, owner_name, owner_mail, sb_payment_no, message_enabled, created_at, updated_at) VALUES (2, '株式会社テストだ', '00000001', '0000001', 'テスト県テスト町 1-2-5', 'テストの代表', 'mail@mailtest.test', '6666666666', 1, '2020-05-18 22:17:14', '2020-06-10 14:04:40');
INSERT INTO companies (id, name, phone, postcode, address, owner_name, owner_mail, sb_payment_no, message_enabled, created_at, updated_at) VALUES (3, 'テステスト株式会社', '00011112222', '7561234', 'テスト市テスト町', '今田公一', 'test@gmail.com', '111111', 0, '2020-05-25 10:29:32', '2020-05-28 12:12:49');
INSERT INTO companies (id, name, phone, postcode, address, owner_name, owner_mail, sb_payment_no, message_enabled, created_at, updated_at) VALUES (4, 'imada株式会社', '99999999999', '5555555', 'テスト市テスト町', '今田公一', 'test@gmail.com', '666666', 1, '2020-05-29 10:09:13', '2020-05-29 10:09:13');
INSERT INTO companies (id, name, phone, postcode, address, owner_name, owner_mail, sb_payment_no, message_enabled, created_at, updated_at) VALUES (5, '日本株式会社', '0008887777', '1234352', 'テスト市テスト町どこ', '誰か', 'test@gmail.com', '555555', 1, '2020-05-29 15:00:40', '2020-05-29 15:43:45');

SET FOREIGN_KEY_CHECKS = 1;