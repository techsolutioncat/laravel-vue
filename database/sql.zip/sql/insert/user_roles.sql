SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO user_roles (id, role, auth, created_at, updated_at) VALUES (1, 'system', 10, null, null);
INSERT INTO user_roles (id, role, auth, created_at, updated_at) VALUES (2, 'admin', 5, null, null);
INSERT INTO user_roles (id, role, auth, created_at, updated_at) VALUES (3, 'user', 1, null, null);

SET FOREIGN_KEY_CHECKS = 1;