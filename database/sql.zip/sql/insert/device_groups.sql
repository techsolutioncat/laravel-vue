SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_groups (id, name, created_at, updated_at) VALUES (1, 'テストグループ', '2020-07-12 14:14:04', '2020-07-12 14:14:06');

SET FOREIGN_KEY_CHECKS = 1;