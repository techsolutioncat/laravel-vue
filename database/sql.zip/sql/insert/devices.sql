SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO devices (id, imei, device_type_id, created_at, updated_at) VALUES (1, '863949040086260', 1, '2020-05-18 22:48:09', '2020-05-18 22:48:09');
INSERT INTO devices (id, imei, device_type_id, created_at, updated_at) VALUES (2, '863949040226775', 2, '2020-05-18 22:48:14', '2020-05-18 22:48:14');
INSERT INTO devices (id, imei, device_type_id, created_at, updated_at) VALUES (3, '863949040226791', 3, '2020-05-22 18:55:30', '2020-05-22 18:55:30');
INSERT INTO devices (id, imei, device_type_id, created_at, updated_at) VALUES (4, '863949040225876', 3, '2020-07-12 14:05:51', '2020-07-12 14:05:58');

SET FOREIGN_KEY_CHECKS = 1;