SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (1, 1, 1, 'signal 1', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (2, 1, 2, 'signal 2', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (3, 1, 3, 'signal 3', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (4, 1, 4, 'signal 4', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (5, 2, 1, 'signal 1', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (6, 2, 2, 'signal 2', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (7, 2, 3, 'signal 3', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (8, 2, 4, 'signal 4', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (9, 3, 1, 'signal 1', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (10, 3, 2, 'signal 2', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (11, 3, 3, 'signal 3', null, null);
INSERT INTO messages (id, device_assignment_id, device_signal_id, message, created_at, updated_at) VALUES (12, 3, 4, 'signal 4', null, null);

SET FOREIGN_KEY_CHECKS = 1;