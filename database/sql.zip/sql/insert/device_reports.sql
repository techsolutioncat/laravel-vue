SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (1, 1, 1, 34.2638016, 132.53288, 100, null, null, null, '補足コメント');
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (2, 1, 2, 34.2638016, 132.53288, 100, null, null, null, '補足コメント');
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (3, 1, 3, 34.2638016, 132.53288, 50, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (4, 1, 4, 34.2638016, 132.53288, 50, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (5, 1, 5, 34.2638016, 132.53288, 50, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (6, 1, 6, 34.2638016, 132.53288, 20, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (7, 1, 7, 34.2638016, 132.53288, 20, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (8, 1, 8, 34.2638016, 132.53288, 100, null, null, null, '非対応');
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (9, 1, 8, 34.2638016, 132.53288, 100, '2020-07-12 15:28:14', '2020-05-20 08:37:30', '2020-07-12 15:28:14', '対応済み');
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (10, 3, 8, 0, 0, 0, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (11, 3, 8, 0, 0, 0, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (12, 2, 1, 34.2638016, 132.53288, 100, null, null, null, '補足コメント');
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (13, 2, 2, 34.2638016, 132.53288, 100, null, null, null, '補足コメント');
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (14, 2, 3, 34.2638016, 132.53288, 50, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (15, 2, 4, 34.2638016, 132.53288, 50, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (16, 2, 5, 34.2638016, 132.53288, 50, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (17, 2, 6, 34.2638016, 132.53288, 20, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (18, 2, 7, 34.2638016, 132.53288, 20, null, null, null, null);
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (19, 2, 8, 34.2638016, 132.53288, 100, null, null, null, '非対応');
INSERT INTO device_reports (id, device_assignment_id, device_signal_id, lat, lng, battery, dealt_with_at, created_at, updated_at, supplement) VALUES (20, 2, 8, 34.2638016, 132.53288, 100, '2020-07-12 15:28:14', '2020-05-20 08:37:30', '2020-07-12 15:28:14', '対応済み');

SET FOREIGN_KEY_CHECKS = 1;