SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_types (id, type, created_at, updated_at) VALUES (1, 'JPTL-402', '2020-05-18 22:48:09', '2020-05-18 22:48:09');
INSERT INTO device_types (id, type, created_at, updated_at) VALUES (2, 'JPTL-403', '2020-05-18 22:48:11', '2020-05-18 22:48:11');
INSERT INTO device_types (id, type, created_at, updated_at) VALUES (3, 'JPTL-401', '2020-05-18 22:48:14', '2020-05-18 22:48:14');
INSERT INTO device_types (id, type, created_at, updated_at) VALUES (4, 'JPTL-401-T', '2020-06-08 03:04:15', '2020-06-08 03:04:15');

SET FOREIGN_KEY_CHECKS = 1;