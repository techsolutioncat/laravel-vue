SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (1, 1, 1, 'signal 1', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (2, 1, 2, 'signal 2', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (3, 1, 3, 'signal 3', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (4, 1, 4, 'signal 4', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (5, 2, 1, 'signal 1', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (6, 2, 2, 'signal 2', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (7, 2, 3, 'signal 3', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (8, 2, 4, 'signal 4', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (9, 3, 1, 'signal 1', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (10, 3, 2, 'signal 2', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (11, 3, 3, 'signal 3', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (12, 3, 4, 'signal 4', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (13, 4, 1, 'signal 1', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (14, 4, 2, 'signal 2', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (15, 4, 3, 'signal 3', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (16, 4, 4, 'signal 4', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (17, 5, 1, 'signal 1', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (18, 5, 2, 'signal 2', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (19, 5, 3, 'signal 3', null, null);
INSERT INTO device_setting_messages (id, device_setting_id, device_signal_id, message, updated_at, created_At) VALUES (20, 5, 4, 'signal 4', null, null);

SET FOREIGN_KEY_CHECKS = 1;