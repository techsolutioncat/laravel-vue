SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (1, 'SOS OR MD Cancelled', 1, '緊急ブザー', null, null);
INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (2, 'Making a call', 2, '緊急通報', '2020-05-18 22:17:15', '2020-05-18 22:17:15');
INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (3, 'BATTERY LOW', 3, 'バッテリー低下', '2020-05-18 22:17:15', '2020-05-18 22:17:15');
INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (4, 'POWER OFF NOW', 4, '電源OFF', '2020-05-18 22:17:15', '2020-05-18 22:17:15');
INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (5, 'POWER ON NOW', 5, '電源ON', '2020-05-18 22:17:15', '2020-05-18 22:17:15');
INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (6, 'Calling', 6, '電話着信', '2020-05-18 22:17:15', '2020-05-18 22:17:15');
INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (7, 'CMD-F', 7, '位置情報問い合わせ', '2020-05-18 22:17:15', '2020-05-18 22:17:15');
INSERT INTO device_signals (id, response, signal_int, description, created_at, updated_at) VALUES (8, 'CMD-A', 8, '電話番号の設定', '2020-05-18 22:17:15', '2020-05-18 22:17:15');

SET FOREIGN_KEY_CHECKS = 1;