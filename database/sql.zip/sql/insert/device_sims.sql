SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_sims (id, device_imei, sim_iccid, active, battery, deleted_at, created_at, updated_at) VALUES (1, '863949040226791', '8981200290670154960', 0, 0, null, '2020-05-22 18:55:30', '2020-05-22 18:55:30');
INSERT INTO device_sims (id, device_imei, sim_iccid, active, battery, deleted_at, created_at, updated_at) VALUES (2, '863949040226775', '8981200290670155017', 0, 0, null, '2020-05-18 22:48:10', '2020-05-18 22:48:10');
INSERT INTO device_sims (id, device_imei, sim_iccid, active, battery, deleted_at, created_at, updated_at) VALUES (3, '863949040225876', '8981200290670154952', 0, 0, null, '2020-05-18 22:48:14', '2020-05-18 22:48:14');

SET FOREIGN_KEY_CHECKS = 1;