SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (1, 1, 2, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (2, 1, 3, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (3, 2, 2, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (4, 2, 3, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (5, 3, 2, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (6, 3, 3, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (7, 4, 2, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (8, 4, 3, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (9, 12, 1, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (10, 12, 3, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (11, 13, 1, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (12, 13, 3, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (13, 14, 1, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (14, 14, 3, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (15, 15, 1, 0, null, null);
INSERT INTO device_report_messages (id, device_report_id, device_assignment_id, received, created_at, updated_at) VALUES (16, 13, 3, 0, null, null);

SET FOREIGN_KEY_CHECKS = 1;